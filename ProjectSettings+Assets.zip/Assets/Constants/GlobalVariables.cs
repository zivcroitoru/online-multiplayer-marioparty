using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlobalVariables
{
    public static string UserId = string.Empty;
    public static int TurnTime = 10;
}
